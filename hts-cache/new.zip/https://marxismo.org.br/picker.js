<!DOCTYPE html>
<html lang="pt-BR" prefix="og: http://ogp.me/ns#">
<head>
<meta charset="UTF-8" />
<link rel="profile" href="https://gmpg.org/xfn/11" />
<link rel="pingback" href="https://marxismo.org.br/xmlrpc.php" />
<title>Página não encontrada &#8211; Organização Comunista Internacionalista (Esquerda Marxista)</title>
<meta name='robots' content='max-image-preview:large' />
<link rel='dns-prefetch' href='//secure.gravatar.com' />
<link rel='dns-prefetch' href='//stats.wp.com' />
<link rel='dns-prefetch' href='//i0.wp.com' />
<link rel='dns-prefetch' href='//c0.wp.com' />
<link rel="alternate" type="application/rss+xml" title="Feed para Organização Comunista Internacionalista (Esquerda Marxista) &raquo;" href="https://marxismo.org.br/feed/" />
<link rel="alternate" type="application/rss+xml" title="Feed de comentários para Organização Comunista Internacionalista (Esquerda Marxista) &raquo;" href="https://marxismo.org.br/comments/feed/" />
<script type="text/javascript">
/* <![CDATA[ */
window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/15.0.3\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/15.0.3\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/marxismo.org.br\/wp-includes\/js\/wp-emoji-release.min.js"}};
/*! This file is auto-generated */
!function(i,n){var o,s,e;function c(e){try{var t={supportTests:e,timestamp:(new Date).valueOf()};sessionStorage.setItem(o,JSON.stringify(t))}catch(e){}}function p(e,t,n){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);var t=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data),r=(e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(n,0,0),new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data));return t.every(function(e,t){return e===r[t]})}function u(e,t,n){switch(t){case"flag":return n(e,"\ud83c\udff3\ufe0f\u200d\u26a7\ufe0f","\ud83c\udff3\ufe0f\u200b\u26a7\ufe0f")?!1:!n(e,"\ud83c\uddfa\ud83c\uddf3","\ud83c\uddfa\u200b\ud83c\uddf3")&&!n(e,"\ud83c\udff4\udb40\udc67\udb40\udc62\udb40\udc65\udb40\udc6e\udb40\udc67\udb40\udc7f","\ud83c\udff4\u200b\udb40\udc67\u200b\udb40\udc62\u200b\udb40\udc65\u200b\udb40\udc6e\u200b\udb40\udc67\u200b\udb40\udc7f");case"emoji":return!n(e,"\ud83d\udc26\u200d\u2b1b","\ud83d\udc26\u200b\u2b1b")}return!1}function f(e,t,n){var r="undefined"!=typeof WorkerGlobalScope&&self instanceof WorkerGlobalScope?new OffscreenCanvas(300,150):i.createElement("canvas"),a=r.getContext("2d",{willReadFrequently:!0}),o=(a.textBaseline="top",a.font="600 32px Arial",{});return e.forEach(function(e){o[e]=t(a,e,n)}),o}function t(e){var t=i.createElement("script");t.src=e,t.defer=!0,i.head.appendChild(t)}"undefined"!=typeof Promise&&(o="wpEmojiSettingsSupports",s=["flag","emoji"],n.supports={everything:!0,everythingExceptFlag:!0},e=new Promise(function(e){i.addEventListener("DOMContentLoaded",e,{once:!0})}),new Promise(function(t){var n=function(){try{var e=JSON.parse(sessionStorage.getItem(o));if("object"==typeof e&&"number"==typeof e.timestamp&&(new Date).valueOf()<e.timestamp+604800&&"object"==typeof e.supportTests)return e.supportTests}catch(e){}return null}();if(!n){if("undefined"!=typeof Worker&&"undefined"!=typeof OffscreenCanvas&&"undefined"!=typeof URL&&URL.createObjectURL&&"undefined"!=typeof Blob)try{var e="postMessage("+f.toString()+"("+[JSON.stringify(s),u.toString(),p.toString()].join(",")+"));",r=new Blob([e],{type:"text/javascript"}),a=new Worker(URL.createObjectURL(r),{name:"wpTestEmojiSupports"});return void(a.onmessage=function(e){c(n=e.data),a.terminate(),t(n)})}catch(e){}c(n=f(s,u,p))}t(n)}).then(function(e){for(var t in e)n.supports[t]=e[t],n.supports.everything=n.supports.everything&&n.supports[t],"flag"!==t&&(n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&n.supports[t]);n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&!n.supports.flag,n.DOMReady=!1,n.readyCallback=function(){n.DOMReady=!0}}).then(function(){return e}).then(function(){var e;n.supports.everything||(n.readyCallback(),(e=n.source||{}).concatemoji?t(e.concatemoji):e.wpemoji&&e.twemoji&&(t(e.twemoji),t(e.wpemoji)))}))}((window,document),window._wpemojiSettings);
/* ]]> */
</script>
<style id='wp-emoji-styles-inline-css' type='text/css'>

	img.wp-smiley, img.emoji {
		display: inline !important;
		border: none !important;
		box-shadow: none !important;
		height: 1em !important;
		width: 1em !important;
		margin: 0 0.07em !important;
		vertical-align: -0.1em !important;
		background: none !important;
		padding: 0 !important;
	}
</style>
<link rel='stylesheet' id='wp-block-library-css' href='https://c0.wp.com/c/6.6.1/wp-includes/css/dist/block-library/style.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='mediaelement-css' href='https://c0.wp.com/c/6.6.1/wp-includes/js/mediaelement/mediaelementplayer-legacy.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='wp-mediaelement-css' href='https://c0.wp.com/c/6.6.1/wp-includes/js/mediaelement/wp-mediaelement.min.css' type='text/css' media='all' />
<style id='jetpack-sharing-buttons-style-inline-css' type='text/css'>
.jetpack-sharing-buttons__services-list{display:flex;flex-direction:row;flex-wrap:wrap;gap:0;list-style-type:none;margin:5px;padding:0}.jetpack-sharing-buttons__services-list.has-small-icon-size{font-size:12px}.jetpack-sharing-buttons__services-list.has-normal-icon-size{font-size:16px}.jetpack-sharing-buttons__services-list.has-large-icon-size{font-size:24px}.jetpack-sharing-buttons__services-list.has-huge-icon-size{font-size:36px}@media print{.jetpack-sharing-buttons__services-list{display:none!important}}.editor-styles-wrapper .wp-block-jetpack-sharing-buttons{gap:0;padding-inline-start:0}ul.jetpack-sharing-buttons__services-list.has-background{padding:1.25em 2.375em}
</style>
<style id='pdfemb-pdf-embedder-viewer-style-inline-css' type='text/css'>
.wp-block-pdfemb-pdf-embedder-viewer{max-width:none}

</style>
<style id='classic-theme-styles-inline-css' type='text/css'>
/*! This file is auto-generated */
.wp-block-button__link{color:#fff;background-color:#32373c;border-radius:9999px;box-shadow:none;text-decoration:none;padding:calc(.667em + 2px) calc(1.333em + 2px);font-size:1.125em}.wp-block-file__button{background:#32373c;color:#fff;text-decoration:none}
</style>
<style id='global-styles-inline-css' type='text/css'>
:root{--wp--preset--aspect-ratio--square: 1;--wp--preset--aspect-ratio--4-3: 4/3;--wp--preset--aspect-ratio--3-4: 3/4;--wp--preset--aspect-ratio--3-2: 3/2;--wp--preset--aspect-ratio--2-3: 2/3;--wp--preset--aspect-ratio--16-9: 16/9;--wp--preset--aspect-ratio--9-16: 9/16;--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgba(255, 255, 255, 1), 6px 6px rgba(0, 0, 0, 1);--wp--preset--shadow--crisp: 6px 6px 0px rgba(0, 0, 0, 1);}:where(.is-layout-flex){gap: 0.5em;}:where(.is-layout-grid){gap: 0.5em;}body .is-layout-flex{display: flex;}.is-layout-flex{flex-wrap: wrap;align-items: center;}.is-layout-flex > :is(*, div){margin: 0;}body .is-layout-grid{display: grid;}.is-layout-grid > :is(*, div){margin: 0;}:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}
:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}
:root :where(.wp-block-pullquote){font-size: 1.5em;line-height: 1.6;}
</style>
<link rel='stylesheet' id='searchandfilter-css' href='https://marxismo.org.br/wp-content/plugins/search-filter/style.css' type='text/css' media='all' />
<link rel='stylesheet' id='tie-style-css' href='https://marxismo.org.br/wp-content/themes/sahifa/style.css' type='text/css' media='all' />
<link rel='stylesheet' id='tie-ilightbox-skin-css' href='https://marxismo.org.br/wp-content/themes/sahifa/css/ilightbox/dark-skin/skin.css' type='text/css' media='all' />
<link rel='stylesheet' id='um_modal-css' href='https://marxismo.org.br/wp-content/plugins/ultimate-member/assets/css/um-modal.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='um_ui-css' href='https://marxismo.org.br/wp-content/plugins/ultimate-member/assets/libs/jquery-ui/jquery-ui.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='um_tipsy-css' href='https://marxismo.org.br/wp-content/plugins/ultimate-member/assets/libs/tipsy/tipsy.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='um_raty-css' href='https://marxismo.org.br/wp-content/plugins/ultimate-member/assets/libs/raty/um-raty.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='select2-css' href='https://marxismo.org.br/wp-content/plugins/ultimate-member/assets/libs/select2/select2.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='um_fileupload-css' href='https://marxismo.org.br/wp-content/plugins/ultimate-member/assets/css/um-fileupload.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='um_confirm-css' href='https://marxismo.org.br/wp-content/plugins/ultimate-member/assets/libs/um-confirm/um-confirm.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='um_datetime-css' href='https://marxismo.org.br/wp-content/plugins/ultimate-member/assets/libs/pickadate/default.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='um_datetime_date-css' href='https://marxismo.org.br/wp-content/plugins/ultimate-member/assets/libs/pickadate/default.date.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='um_datetime_time-css' href='https://marxismo.org.br/wp-content/plugins/ultimate-member/assets/libs/pickadate/default.time.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='um_fonticons_ii-css' href='https://marxismo.org.br/wp-content/plugins/ultimate-member/assets/libs/legacy/fonticons/fonticons-ii.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='um_fonticons_fa-css' href='https://marxismo.org.br/wp-content/plugins/ultimate-member/assets/libs/legacy/fonticons/fonticons-fa.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='um_fontawesome-css' href='https://marxismo.org.br/wp-content/plugins/ultimate-member/assets/css/um-fontawesome.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='um_common-css' href='https://marxismo.org.br/wp-content/plugins/ultimate-member/assets/css/common.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='um_responsive-css' href='https://marxismo.org.br/wp-content/plugins/ultimate-member/assets/css/um-responsive.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='um_styles-css' href='https://marxismo.org.br/wp-content/plugins/ultimate-member/assets/css/um-styles.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='um_crop-css' href='https://marxismo.org.br/wp-content/plugins/ultimate-member/assets/libs/cropper/cropper.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='um_profile-css' href='https://marxismo.org.br/wp-content/plugins/ultimate-member/assets/css/um-profile.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='um_account-css' href='https://marxismo.org.br/wp-content/plugins/ultimate-member/assets/css/um-account.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='um_misc-css' href='https://marxismo.org.br/wp-content/plugins/ultimate-member/assets/css/um-misc.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='um_default_css-css' href='https://marxismo.org.br/wp-content/plugins/ultimate-member/assets/css/um-old-default.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='um_old_css-css' href='https://marxismo.org.br/wp-content/plugins/ultimate-member/../../uploads/ultimatemember/um_old_settings.css' type='text/css' media='all' />
<link rel='stylesheet' id='jetpack_css-css' href='https://c0.wp.com/p/jetpack/13.6/css/jetpack.css' type='text/css' media='all' />
<script type="text/javascript" src="https://c0.wp.com/c/6.6.1/wp-includes/js/jquery/jquery.min.js" id="jquery-core-js"></script>
<script type="text/javascript" src="https://c0.wp.com/c/6.6.1/wp-includes/js/jquery/jquery-migrate.min.js" id="jquery-migrate-js"></script>
<script type="text/javascript" src="https://marxismo.org.br/wp-content/plugins/ultimate-member/assets/js/um-gdpr.min.js" id="um-gdpr-js"></script>
<link rel="https://api.w.org/" href="https://marxismo.org.br/wp-json/" />		<style type="text/css">
			.um_request_name {
				display: none !important;
			}
		</style>
		<style>img#wpstats{display:none}</style>
		<link rel="shortcut icon" href="https://www.marxismo.org.br/wp-content/uploads/2017/09/favicon4.png" title="Favicon" />
<!--[if IE]>
<script type="text/javascript">jQuery(document).ready(function (){ jQuery(".menu-item").has("ul").children("a").attr("aria-haspopup", "true");});</script>
<![endif]-->
<!--[if lt IE 9]>
<script src="https://marxismo.org.br/wp-content/themes/sahifa/js/html5.js"></script>
<script src="https://marxismo.org.br/wp-content/themes/sahifa/js/selectivizr-min.js"></script>
<![endif]-->
<!--[if IE 9]>
<link rel="stylesheet" type="text/css" media="all" href="https://marxismo.org.br/wp-content/themes/sahifa/css/ie9.css" />
<![endif]-->
<!--[if IE 8]>
<link rel="stylesheet" type="text/css" media="all" href="https://marxismo.org.br/wp-content/themes/sahifa/css/ie8.css" />
<![endif]-->
<!--[if IE 7]>
<link rel="stylesheet" type="text/css" media="all" href="https://marxismo.org.br/wp-content/themes/sahifa/css/ie7.css" />
<![endif]-->


<meta name="viewport" content="width=device-width, initial-scale=1.0" />



<style type="text/css" media="screen">

body{
	font-size : 14px;
	font-weight: normal;
	font-style: normal;
}

::-webkit-scrollbar {
	width: 8px;
	height:8px;
}

#main-nav,
.cat-box-content,
#sidebar .widget-container,
.post-listing,
#commentform {
	border-bottom-color: #e8000c;
}

.search-block .search-button,
#topcontrol,
#main-nav ul li.current-menu-item a,
#main-nav ul li.current-menu-item a:hover,
#main-nav ul li.current_page_parent a,
#main-nav ul li.current_page_parent a:hover,
#main-nav ul li.current-menu-parent a,
#main-nav ul li.current-menu-parent a:hover,
#main-nav ul li.current-page-ancestor a,
#main-nav ul li.current-page-ancestor a:hover,
.pagination span.current,
.share-post span.share-text,
.flex-control-paging li a.flex-active,
.ei-slider-thumbs li.ei-slider-element,
.review-percentage .review-item span span,
.review-final-score,
.button,
a.button,
a.more-link,
#main-content input[type="submit"],
.form-submit #submit,
#login-form .login-button,
.widget-feedburner .feedburner-subscribe,
input[type="submit"],
#buddypress button,
#buddypress a.button,
#buddypress input[type=submit],
#buddypress input[type=reset],
#buddypress ul.button-nav li a,
#buddypress div.generic-button a,
#buddypress .comment-reply-link,
#buddypress div.item-list-tabs ul li a span,
#buddypress div.item-list-tabs ul li.selected a,
#buddypress div.item-list-tabs ul li.current a,
#buddypress #members-directory-form div.item-list-tabs ul li.selected span,
#members-list-options a.selected,
#groups-list-options a.selected,
body.dark-skin #buddypress div.item-list-tabs ul li a span,
body.dark-skin #buddypress div.item-list-tabs ul li.selected a,
body.dark-skin #buddypress div.item-list-tabs ul li.current a,
body.dark-skin #members-list-options a.selected,
body.dark-skin #groups-list-options a.selected,
.search-block-large .search-button,
#featured-posts .flex-next:hover,
#featured-posts .flex-prev:hover,
a.tie-cart span.shooping-count,
.woocommerce span.onsale,
.woocommerce-page span.onsale ,
.woocommerce .widget_price_filter .ui-slider .ui-slider-handle,
.woocommerce-page .widget_price_filter .ui-slider .ui-slider-handle,
#check-also-close,
a.post-slideshow-next,
a.post-slideshow-prev,
.widget_price_filter .ui-slider .ui-slider-handle,
.quantity .minus:hover,
.quantity .plus:hover,
.mejs-container .mejs-controls .mejs-time-rail .mejs-time-current,
#reading-position-indicator  {
	background-color:#e8000c;
}

::-webkit-scrollbar-thumb{
	background-color:#e8000c !important;
}

#theme-footer,
#theme-header,
.top-nav ul li.current-menu-item:before,
#main-nav .menu-sub-content ,
#main-nav ul ul,
#check-also-box {
	border-top-color: #e8000c;
}

.search-block:after {
	border-right-color:#e8000c;
}

body.rtl .search-block:after {
	border-left-color:#e8000c;
}

#main-nav ul > li.menu-item-has-children:hover > a:after,
#main-nav ul > li.mega-menu:hover > a:after {
	border-color:transparent transparent #e8000c;
}

.widget.timeline-posts li a:hover,
.widget.timeline-posts li a:hover span.tie-date {
	color: #e8000c;
}

.widget.timeline-posts li a:hover span.tie-date:before {
	background: #e8000c;
	border-color: #e8000c;
}

#order_review,
#order_review_heading {
	border-color: #e8000c;
}


body {
	background-image : url(https://marxismo.org.br/wp-content/themes/sahifa/images/patterns/body-bg1.png);
	background-position: top center;
}

body.single .post .entry a, body.page .post .entry a {
	color: #d40000;
}
		
body.single .post .entry a:hover, body.page .post .entry a:hover {
	color: #ff0000;
}
		
.social-icons.social-colored .&lt;i class=&quot;fa-brands fa-tiktok&quot; style=&quot;color: #e456b3;&quot;&gt;&lt;/i&gt;:before {
	background: #00b3ff ;
}

.breaking-news span.breaking-news-title {background: #c70000;}

.tie-cat-3237 a.more-link {background-color:#ff0303;}
.tie-cat-3237 .cat-box-content {border-bottom-color:#ff0303; }
			
.tie-cat-6232 a.more-link {background-color:#850000;}
.tie-cat-6232 .cat-box-content {border-bottom-color:#850000; }
			
.tie-cat-8027 a.more-link {background-color:#8c0000;}
.tie-cat-8027 .cat-box-content {border-bottom-color:#8c0000; }
			
header#theme-header #main-nav ul li.menu-item-home a , header#theme-header #main-nav ul li.menu-item-home.current-menu-item a{
    background-image: none !important;
    text-indent: 0;
    width:auto;}</style>

<meta name="generator" content="Elementor 3.23.3; features: additional_custom_breakpoints, e_lazyload; settings: css_print_method-external, google_font-enabled, font_display-auto">
			<style>
				.e-con.e-parent:nth-of-type(n+4):not(.e-lazyloaded):not(.e-no-lazyload),
				.e-con.e-parent:nth-of-type(n+4):not(.e-lazyloaded):not(.e-no-lazyload) * {
					background-image: none !important;
				}
				@media screen and (max-height: 1024px) {
					.e-con.e-parent:nth-of-type(n+3):not(.e-lazyloaded):not(.e-no-lazyload),
					.e-con.e-parent:nth-of-type(n+3):not(.e-lazyloaded):not(.e-no-lazyload) * {
						background-image: none !important;
					}
				}
				@media screen and (max-height: 640px) {
					.e-con.e-parent:nth-of-type(n+2):not(.e-lazyloaded):not(.e-no-lazyload),
					.e-con.e-parent:nth-of-type(n+2):not(.e-lazyloaded):not(.e-no-lazyload) * {
						background-image: none !important;
					}
				}
			</style>
					<style type="text/css" id="wp-custom-css">
			h2 {
  font-size: 2px;
}		</style>
		</head>
<body data-rsssl=1 id="top" class="error404 wp-custom-logo lazy-enabled elementor-default elementor-kit-27993">

<div class="wrapper-outer">

	<div class="background-cover"></div>

	<aside id="slide-out">

			<div class="search-mobile">
			<form method="get" id="searchform-mobile" action="https://marxismo.org.br/">
				<button class="search-button" type="submit" value="Pesquisa"><i class="fa fa-search"></i></button>
				<input type="text" id="s-mobile" name="s" title="Pesquisa" value="Pesquisa" onfocus="if (this.value == 'Pesquisa') {this.value = '';}" onblur="if (this.value == '') {this.value = 'Pesquisa';}"  />
			</form>
		</div><!-- .search-mobile /-->
	
			<div class="social-icons">
		<a class="ttip-none" title="Facebook" href="https://www.facebook.com/oci.comunista" target="_blank"><i class="fa fa-facebook"></i></a><a class="ttip-none" title="Twitter" href="https://twitter.com/oci_comunista" target="_blank"><i class="fa fa-twitter"></i></a><a class="ttip-none" title="Youtube" href="https://www.youtube.com/user/esquerdamarxista" target="_blank"><i class="fa fa-youtube"></i></a><a class="ttip-none" title="instagram" href="https://www.instagram.com/oci.comunista/" target="_blank"><i class="fa fa-instagram"></i></a><a class="ttip-none" title="spotify" href="https://open.spotify.com/show/4fIEqAeSsFtSqOTC11xhwP?si=7c90538949c54da8" target="_blank"><i class="fa fa-spotify"></i></a>
		<a class="ttip-none"  title="TikTok" href="https://www.tiktok.com/@oci.comunista" target="_blank"><i class="fa &lt;i class=&quot;fa-brands fa-tiktok&quot; style=&quot;color: #e456b3;&quot;&gt;&lt;/i&gt;"></i></a>	</div>

	
		<div id="mobile-menu"  class="mobile-hide-icons"></div>
	</aside><!-- #slide-out /-->

		<div id="wrapper" class="wide-layout">
		<div class="inner-wrapper">

		<header id="theme-header" class="theme-header center-logo">
			
		<div class="header-content">

					<a id="slide-out-open" class="slide-out-open" href="#"><span></span></a>
		
			<div class="logo">
			<h2>								<a title="Organização Comunista Internacionalista (Esquerda Marxista)" href="https://marxismo.org.br/">
					<img src="https://www.marxismo.org.br/wp-content/uploads/2024/06/Logo-OCI-ICR-500px.png" alt="Organização Comunista Internacionalista (Esquerda Marxista)"  /><strong>Organização Comunista Internacionalista (Esquerda Marxista) Corrente Marxista Internacional</strong>
				</a>
			</h2>			</div><!-- .logo /-->
			<div class="e3lan e3lan-top">
			<a href="https://www.marxismo.org.br/a-esquerda-marxista-agora-e-a-organizacao-comunista-internacionalista/" title="A Esquerda Marxista agora é a Organização Comunista Internacionalista" target="_blank">
				<img src="https://www.marxismo.org.br/wp-content/uploads/2023/11/a-em-e-a-oci-700px-2.png" alt="A Esquerda Marxista agora é a Organização Comunista Internacionalista" />
			</a>
				</div>			<div class="clear"></div>

		</div>
													<nav id="main-nav">
				<div class="container">

				
					<div class="main-menu"><ul id="menu-principal" class="menu"><li id="menu-item-38462" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-38462"><a href="https://marxismo.org.br/">Início</a></li>
<li id="menu-item-38463" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-38463"><a href="https://marxismo.org.br/artigos/">Artigos</a>
<ul class="sub-menu menu-sub-content">
	<li id="menu-item-38466" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-38466"><a href="https://marxismo.org.br/artigos/brasil/">Brasil</a></li>
	<li id="menu-item-38475" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-38475"><a href="https://marxismo.org.br/artigos/mundo/">Mundo</a></li>
	<li id="menu-item-38511" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-38511"><a href="https://marxismo.org.br/artigos/luta-de-classes/">Luta de Classes</a>
	<ul class="sub-menu menu-sub-content">
		<li id="menu-item-38472" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-38472"><a href="https://marxismo.org.br/artigos/luta-de-classes/juventude/">Juventude</a></li>
		<li id="menu-item-38473" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-38473"><a href="https://marxismo.org.br/artigos/luta-de-classes/movimento-negro/">Movimento Negro</a></li>
		<li id="menu-item-43345" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-43345"><a href="https://marxismo.org.br/mulherespelosocialismo/">Mulheres</a></li>
		<li id="menu-item-52532" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-52532"><a href="https://marxismo.org.br/identitarismo/">Identitarismo</a></li>
		<li id="menu-item-38491" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-38491"><a href="https://marxismo.org.br/artigos/luta-de-classes/sindical/">Sindical</a></li>
		<li id="menu-item-38470" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-38470"><a href="https://marxismo.org.br/artigos/luta-de-classes/economia/">Economia</a></li>
		<li id="menu-item-38471" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-38471"><a href="https://marxismo.org.br/artigos/luta-de-classes/educacao/">Educação</a></li>
		<li id="menu-item-38468" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-38468"><a href="https://marxismo.org.br/artigos/luta-de-classes/arte-cultura/">Arte &amp; Cultura</a></li>
		<li id="menu-item-38469" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-38469"><a href="https://marxismo.org.br/artigos/luta-de-classes/ciencia-tecnologia/">Ciência &amp; Tecnologia</a></li>
	</ul>
</li>
	<li id="menu-item-49742" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-49742"><a href="https://marxismo.org.br/artigos/imprensa-comunista/">Imprensa Comunista</a></li>
	<li id="menu-item-38481" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-38481"><a href="https://marxismo.org.br/especiais/">Especiais</a>
	<ul class="sub-menu menu-sub-content">
		<li id="menu-item-51378" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-51378"><a href="https://marxismo.org.br/especiais/ditadura-nunca-mais-60-anos-do-golpe-militar/">Ditadura Nunca Mais: 60 anos do golpe militar</a></li>
		<li id="menu-item-43365" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-43365"><a href="https://marxismo.org.br/coletanea-roque-ferreira/">Coletânea Roque Ferreira</a></li>
		<li id="menu-item-38484" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-38484"><a href="https://marxismo.org.br/especiais/covid-19/">Covid-19</a></li>
		<li id="menu-item-38485" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-38485"><a href="https://marxismo.org.br/especiais/psol/">Nossa luta no PSOL</a></li>
	</ul>
</li>
</ul>
</li>
<li id="menu-item-38487" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-38487"><a href="https://marxismo.org.br/teoria/">Teoria</a>
<ul class="sub-menu menu-sub-content">
	<li id="menu-item-38497" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-38497"><a href="https://marxismo.org.br/teoria/dialetica-e-materialismo/">Dialética e Materialismo</a></li>
	<li id="menu-item-38504" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-38504"><a href="https://marxismo.org.br/teoria/historia/">História</a>
	<ul class="sub-menu menu-sub-content">
		<li id="menu-item-47924" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-47924"><a href="https://marxismo.org.br/teoria/a-comuna-de-paris/">A Comuna de Paris</a></li>
		<li id="menu-item-38492" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-38492"><a href="https://marxismo.org.br/teoria/historia/a-revolucao-russa/">A Revolução Russa</a></li>
		<li id="menu-item-38493" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-38493"><a href="https://marxismo.org.br/teoria/historia/as-internacionais/">As Internacionais</a></li>
		<li id="menu-item-38494" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-38494"><a href="https://marxismo.org.br/teoria/historia/brasil-historia/">História do Brasil</a></li>
		<li id="menu-item-38495" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-38495"><a href="https://marxismo.org.br/teoria/historia/historia-geral/">História Geral</a></li>
		<li id="menu-item-38496" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-38496"><a href="https://marxismo.org.br/teoria/historia/movimento-operario/">Movimento Operário</a></li>
		<li id="menu-item-38490" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-38490"><a href="https://marxismo.org.br/teoria/historia/revolucoes-seculo-20/">Revoluções do Século 20</a></li>
	</ul>
</li>
	<li id="menu-item-38505" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-38505"><a href="https://marxismo.org.br/teoria/livros-teoria/">Livros</a></li>
	<li id="menu-item-38500" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-38500"><a href="https://marxismo.org.br/teoria/mulheres-teoria/">Mulheres</a></li>
	<li id="menu-item-38502" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-38502"><a href="https://marxismo.org.br/teoria/racismo-racialismo/">Racismo &amp; Racialismo</a></li>
	<li id="menu-item-38488" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-38488"><a href="https://marxismo.org.br/teoria/teoria-economica/">Teoria Econômica</a></li>
</ul>
</li>
<li id="menu-item-43217" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-43217"><a href="https://marxismo.org.br/nossas-lutas/">Nossas Lutas</a>
<ul class="sub-menu menu-sub-content">
	<li id="menu-item-43218" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-43218"><a href="https://marxismo.org.br/nossas-lutas/">Relatos</a></li>
	<li id="menu-item-39354" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-39354"><a href="https://marxismo.org.br/campanhas/">Campanhas</a>
	<ul class="sub-menu menu-sub-content">
		<li id="menu-item-47923" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-47923"><a href="https://www.marxismo.org.br/artigos/luta-de-classes/juventude/revoga-nem/">Revoga Novo Ensino Médio</a></li>
		<li id="menu-item-46164" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-46164"><a href="https://marxismo.org.br/fabricas-ocupadas-20-anos/">Fábricas Ocupadas 20 Anos</a></li>
	</ul>
</li>
</ul>
</li>
<li id="menu-item-38476" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-38476 mega-menu mega-recent-featured "><a href="https://marxismo.org.br/documentos/">Documentos</a>
<div class="mega-menu-block menu-sub-content">

<ul class="mega-recent-featured-list sub-list">
	<li id="menu-item-38477" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-38477"><a href="https://marxismo.org.br/documentos/congressos-conferencias/">Congressos &amp; Conferências</a></li>
	<li id="menu-item-38478" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-38478"><a href="https://marxismo.org.br/documentos/editoriais/">Editoriais</a></li>
	<li id="menu-item-38480" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-38480"><a href="https://marxismo.org.br/documentos/resolucoes-declaracoes/">Resoluções &amp; Declarações</a></li>
	<li id="menu-item-38479" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-38479"><a href="https://marxismo.org.br/documentos/fabricas-ocupadas/">Fábricas Ocupadas</a></li>
	<li id="menu-item-51975" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-51975"><a href="https://marxismo.org.br/documentos/internacional-comunista-revolucionaria/">Internacional Comunista Revolucionária</a></li>
</ul>

<div class="mega-menu-content">
<div class="mega-recent-post"><div class="post-thumbnail"><a class="mega-menu-link" href="https://marxismo.org.br/saudacao-de-ivan-pinheiro-a-conferencia-de-fundacao-da-internacional-comunista-revolucionaria/" title="Saudação de Ivan Pinheiro à conferência de fundação da Internacional Comunista Revolucionária"><img fetchpriority="high" src="https://i0.wp.com/marxismo.org.br/wp-content/uploads/2024/06/ivan-pinheiro-1.png?resize=660%2C330&ssl=1" width="660" height="330" alt="Saudação de Ivan Pinheiro à conferência de fundação da Internacional Comunista Revolucionária" /><span class="fa overlay-icon"></span></a></div><h3 class="post-box-title"><a class="mega-menu-link" href="https://marxismo.org.br/saudacao-de-ivan-pinheiro-a-conferencia-de-fundacao-da-internacional-comunista-revolucionaria/" title="Saudação de Ivan Pinheiro à conferência de fundação da Internacional Comunista Revolucionária">Saudação de Ivan Pinheiro à conferência de fundação da Internacional Comunista Revolucionária</a></h3>
						<span class="tie-date"><i class="fa fa-clock-o"></i>20/06/2024</span>
						</div> <!-- mega-recent-post --><div class="mega-check-also"><ul><li><div class="post-thumbnail"><a class="mega-menu-link" href="https://marxismo.org.br/a-internacional-comunista-revolucionaria-chegou/" title="A Internacional Comunista Revolucionária chegou!"><img src="https://i0.wp.com/marxismo.org.br/wp-content/uploads/2024/06/RCI_founding2_Image_own_work-scaled.jpg?resize=110%2C75&ssl=1" width="110" height="75" alt="A Internacional Comunista Revolucionária chegou!" /><span class="fa overlay-icon"></span></a></div><h3 class="post-box-title"><a class="mega-menu-link" href="https://marxismo.org.br/a-internacional-comunista-revolucionaria-chegou/" title="A Internacional Comunista Revolucionária chegou!">A Internacional Comunista Revolucionária chegou!</a></h3><span class="tie-date"><i class="fa fa-clock-o"></i>17/06/2024</span></li><li><div class="post-thumbnail"><a class="mega-menu-link" href="https://marxismo.org.br/manifesto-da-internacional-comunista-revolucionaria/" title="Manifesto da Internacional Comunista Revolucionária"><img src="https://i0.wp.com/marxismo.org.br/wp-content/uploads/2024/03/manifesto-graphic-website.jpg?resize=110%2C75&ssl=1" width="110" height="75" alt="Manifesto da Internacional Comunista Revolucionária" /><span class="fa overlay-icon"></span></a></div><h3 class="post-box-title"><a class="mega-menu-link" href="https://marxismo.org.br/manifesto-da-internacional-comunista-revolucionaria/" title="Manifesto da Internacional Comunista Revolucionária">Manifesto da Internacional Comunista Revolucionária</a></h3><span class="tie-date"><i class="fa fa-clock-o"></i>15/06/2024</span></li><li><div class="post-thumbnail"><a class="mega-menu-link" href="https://marxismo.org.br/como-os-militantes-da-cmi-intervem-no-movimento-de-solidariedade-com-a-palestina/" title="Como os militantes da CMI intervêm no movimento de solidariedade com a Palestina"><img loading="lazy" src="https://i0.wp.com/marxismo.org.br/wp-content/uploads/2024/05/comrades_Image_Revolutionary_Communists_of_America.jpeg?resize=110%2C75&ssl=1" width="110" height="75" alt="Como os militantes da CMI intervêm no movimento de solidariedade com a Palestina" /><span class="fa overlay-icon"></span></a></div><h3 class="post-box-title"><a class="mega-menu-link" href="https://marxismo.org.br/como-os-militantes-da-cmi-intervem-no-movimento-de-solidariedade-com-a-palestina/" title="Como os militantes da CMI intervêm no movimento de solidariedade com a Palestina">Como os militantes da CMI intervêm no movimento de solidariedade com a Palestina</a></h3><span class="tie-date"><i class="fa fa-clock-o"></i>16/05/2024</span></li></ul></div> <!-- mega-check-also -->
</div><!-- .mega-menu-content --> 
</div><!-- .mega-menu-block --> 
</li>
<li id="menu-item-38520" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-38520"><a href="https://marxismo.org.br/multimidia/">Multimídia</a>
<ul class="sub-menu menu-sub-content">
	<li id="menu-item-38518" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-38518"><a href="https://marxismo.org.br/podcast/">Podcast</a></li>
	<li id="menu-item-38522" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-38522"><a href="https://marxismo.org.br/multimidia/videos/lives/">Lives</a></li>
	<li id="menu-item-38519" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-38519"><a href="https://marxismo.org.br/multimidia/videos/">Vídeos</a></li>
	<li id="menu-item-38521" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-38521"><a href="https://marxismo.org.br/multimidia/musicas/">Músicas</a></li>
</ul>
</li>
<li id="menu-item-38506" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-38506"><a href="https://marxismo.org.br/publicacoes/">Publicações</a>
<ul class="sub-menu menu-sub-content">
	<li id="menu-item-52884" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-52884"><a href="https://marxismo.org.br/publicacoes/o-comunismo/">O Comunismo</a></li>
	<li id="menu-item-38510" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-38510"><a href="https://marxismo.org.br/publicacoes/revista-america-socialista/">Revista América Socialista</a></li>
	<li id="menu-item-39695" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-39695"><a href="https://marxismo.org.br/publicacoes/tempo-de-revolucao/">Jornal Tempo de Revolução</a></li>
	<li id="menu-item-38507" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-38507"><a href="https://marxismo.org.br/publicacoes/edicoes-jornal-foice-martelo/">Jornal Foice&#038;Martelo</a></li>
	<li id="menu-item-38508" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-38508"><a href="https://marxismo.org.br/publicacoes/jornal-luta-de-classes/">Jornal Luta de Classes</a></li>
</ul>
</li>
<li id="menu-item-38517" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-38517"><a href="https://marxismo.org.br/quem-somos/">Quem somos</a>
<ul class="sub-menu menu-sub-content">
	<li id="menu-item-42788" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-42788"><a href="https://www.marxismo.org.br/quem-somos/">Quem Somos</a></li>
	<li id="menu-item-39425" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-39425"><a href="https://docs.google.com/forms/d/e/1FAIpQLSeUbKf3DydCahiReJvGN3jUKs7H1aRPaoI0kYxNPbixTVNX4Q/viewform">Organize-se na OCI</a></li>
	<li id="menu-item-51749" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-51749"><a href="https://www.marxist.com/">Corrente Marxista Internacional</a></li>
	<li id="menu-item-51750" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-51750"><a href="http://liberdadeeluta.org/">Juventude Comunista Internacionalista</a></li>
	<li id="menu-item-51752" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-51752"><a href="https://www.marxismo.org.br/mulherespelosocialismo/">Mulheres Pelo Socialismo</a></li>
	<li id="menu-item-51849" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-51849"><a href="https://marxismo.org.br/movimento-negro-socialista/">Movimento Negro Socialista</a></li>
	<li id="menu-item-51751" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-51751"><a href="https://livrariamarxista.com.br/">Livraria Marxista</a></li>
</ul>
</li>
<li id="menu-item-51754" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-51754"><a href="https://marxismo.org.br/contato/">Contato</a></li>
</ul></div>					
					
				</div>
			</nav><!-- .main-nav /-->
					</header><!-- #header /-->

	
	<div class="e3lan e3lan-below_header">
			<a href="https://forms.gle/eBNa7aSgNBt52Knw9" title="" target="_blank">
				<img src="https://www.marxismo.org.br/wp-content/uploads/2023/11/banner-pg-campanha-comunista-2.png" alt="" />
			</a>
				</div>
	<div id="main-content" class="container full-width">
	<div class="content">

		<div class="post error404">
			<div class="post-inner">
				<div class="title-404">404 :(</div>
				<h2 class="post-title">Não Encontrado</h2>
				<div class="clear"></div>
				<div class="entry">
					<p>Desculpe, mas a página que você solicitou não foi encontrada. Talvez pesquisar ajude.</p>

					<div class="search-block-large">
						<form method="get" action="https://marxismo.org.br/">
							<button class="search-button" type="submit" value="Pesquisa"><i class="fa fa-search"></i></button>
							<input type="text" id="s" name="s" value="Pesquisa" onfocus="if (this.value == 'Pesquisa') {this.value = '';}" onblur="if (this.value == '') {this.value = 'Pesquisa';}"  />
						</form>
					</div><!-- .search-block /-->
				</div><!-- .entry /-->

				
				<section id="related_posts">
					<div class="block-head">
						<h3>Confira Também</h3><div class="stripe-line"></div>
					</div>
					<div class="post-listing">
												<div class="related-item">
														<div class="post-thumbnail">
								<a href="https://marxismo.org.br/nota-urgente-sobre-a-venezuela-como-chegamos-a-este-beco-sem-saida/" rel="bookmark">
									<img loading="lazy" width="310" height="165" src="https://i0.wp.com/marxismo.org.br/wp-content/uploads/2024/07/eleicoes-venezuela-2024.jpg?resize=310%2C165&amp;ssl=1" class="attachment-tie-medium size-tie-medium wp-post-image" alt="" decoding="async" srcset="https://i0.wp.com/marxismo.org.br/wp-content/uploads/2024/07/eleicoes-venezuela-2024.jpg?resize=310%2C165&amp;ssl=1 310w, https://i0.wp.com/marxismo.org.br/wp-content/uploads/2024/07/eleicoes-venezuela-2024.jpg?zoom=2&amp;resize=310%2C165&amp;ssl=1 620w, https://i0.wp.com/marxismo.org.br/wp-content/uploads/2024/07/eleicoes-venezuela-2024.jpg?zoom=3&amp;resize=310%2C165&amp;ssl=1 930w" sizes="(max-width: 310px) 100vw, 310px" />									<span class="fa overlay-icon"></span>
								</a>
							</div><!-- post-thumbnail /-->
														<h3><a href="https://marxismo.org.br/nota-urgente-sobre-a-venezuela-como-chegamos-a-este-beco-sem-saida/" rel="bookmark">Nota urgente sobre a Venezuela – Como chegamos a este beco sem saída?</a></h3>
							<p class="post-meta"><span class="tie-date"><i class="fa fa-clock-o"></i>30/07/2024</span></p>
						</div>
												<div class="related-item">
														<div class="post-thumbnail">
								<a href="https://marxismo.org.br/por-onde-comecar-como-as-fundacoes-do-bolchevismo-foram-formuladas/" rel="bookmark">
									<img loading="lazy" width="310" height="165" src="https://i0.wp.com/marxismo.org.br/wp-content/uploads/2024/07/iskra.jpg?resize=310%2C165&amp;ssl=1" class="attachment-tie-medium size-tie-medium wp-post-image" alt="" decoding="async" srcset="https://i0.wp.com/marxismo.org.br/wp-content/uploads/2024/07/iskra.jpg?resize=310%2C165&amp;ssl=1 310w, https://i0.wp.com/marxismo.org.br/wp-content/uploads/2024/07/iskra.jpg?zoom=2&amp;resize=310%2C165&amp;ssl=1 620w, https://i0.wp.com/marxismo.org.br/wp-content/uploads/2024/07/iskra.jpg?zoom=3&amp;resize=310%2C165&amp;ssl=1 930w" sizes="(max-width: 310px) 100vw, 310px" />									<span class="fa overlay-icon"></span>
								</a>
							</div><!-- post-thumbnail /-->
														<h3><a href="https://marxismo.org.br/por-onde-comecar-como-as-fundacoes-do-bolchevismo-foram-formuladas/" rel="bookmark">Por onde começar? Como as fundações do bolchevismo foram formuladas</a></h3>
							<p class="post-meta"><span class="tie-date"><i class="fa fa-clock-o"></i>29/07/2024</span></p>
						</div>
												<div class="related-item">
														<div class="post-thumbnail">
								<a href="https://marxismo.org.br/bangladesh-governo-mata-39-estudantes-abaixo-o-regime-assassino/" rel="bookmark">
									<img loading="lazy" width="310" height="165" src="https://i0.wp.com/marxismo.org.br/wp-content/uploads/2024/07/demo_Image_Rayhan9d_Wikimedia_Commons.jpg?resize=310%2C165&amp;ssl=1" class="attachment-tie-medium size-tie-medium wp-post-image" alt="" decoding="async" srcset="https://i0.wp.com/marxismo.org.br/wp-content/uploads/2024/07/demo_Image_Rayhan9d_Wikimedia_Commons.jpg?resize=310%2C165&amp;ssl=1 310w, https://i0.wp.com/marxismo.org.br/wp-content/uploads/2024/07/demo_Image_Rayhan9d_Wikimedia_Commons.jpg?zoom=2&amp;resize=310%2C165&amp;ssl=1 620w, https://i0.wp.com/marxismo.org.br/wp-content/uploads/2024/07/demo_Image_Rayhan9d_Wikimedia_Commons.jpg?zoom=3&amp;resize=310%2C165&amp;ssl=1 930w" sizes="(max-width: 310px) 100vw, 310px" />									<span class="fa overlay-icon"></span>
								</a>
							</div><!-- post-thumbnail /-->
														<h3><a href="https://marxismo.org.br/bangladesh-governo-mata-39-estudantes-abaixo-o-regime-assassino/" rel="bookmark">Bangladesh: governo mata 39 estudantes – abaixo o regime assassino!</a></h3>
							<p class="post-meta"><span class="tie-date"><i class="fa fa-clock-o"></i>20/07/2024</span></p>
						</div>
												<div class="related-item">
														<div class="post-thumbnail">
								<a href="https://marxismo.org.br/30-anos-depois-relembrando-a-cumplicidade-do-imperialismo-frances-no-genocidio-de-ruanda/" rel="bookmark">
									<img loading="lazy" width="310" height="165" src="https://i0.wp.com/marxismo.org.br/wp-content/uploads/2024/07/genocide_memorial_Image_public_domain.jpg?resize=310%2C165&amp;ssl=1" class="attachment-tie-medium size-tie-medium wp-post-image" alt="" decoding="async" srcset="https://i0.wp.com/marxismo.org.br/wp-content/uploads/2024/07/genocide_memorial_Image_public_domain.jpg?resize=310%2C165&amp;ssl=1 310w, https://i0.wp.com/marxismo.org.br/wp-content/uploads/2024/07/genocide_memorial_Image_public_domain.jpg?zoom=2&amp;resize=310%2C165&amp;ssl=1 620w, https://i0.wp.com/marxismo.org.br/wp-content/uploads/2024/07/genocide_memorial_Image_public_domain.jpg?zoom=3&amp;resize=310%2C165&amp;ssl=1 930w" sizes="(max-width: 310px) 100vw, 310px" />									<span class="fa overlay-icon"></span>
								</a>
							</div><!-- post-thumbnail /-->
														<h3><a href="https://marxismo.org.br/30-anos-depois-relembrando-a-cumplicidade-do-imperialismo-frances-no-genocidio-de-ruanda/" rel="bookmark">30 anos depois: relembrando a cumplicidade do imperialismo francês no genocídio de Ruanda</a></h3>
							<p class="post-meta"><span class="tie-date"><i class="fa fa-clock-o"></i>19/07/2024</span></p>
						</div>
												<div class="related-item">
														<div class="post-thumbnail">
								<a href="https://marxismo.org.br/os-motivos-pelos-quais-um-militante-da-oci-renuncia-ao-seu-posto-na-direcao-do-sindicato-dos-metroviarios-de-sp/" rel="bookmark">
									<img loading="lazy" width="310" height="165" src="https://i0.wp.com/marxismo.org.br/wp-content/uploads/2024/08/metroviarios.jpg?resize=310%2C165&amp;ssl=1" class="attachment-tie-medium size-tie-medium wp-post-image" alt="" decoding="async" srcset="https://i0.wp.com/marxismo.org.br/wp-content/uploads/2024/08/metroviarios.jpg?resize=310%2C165&amp;ssl=1 310w, https://i0.wp.com/marxismo.org.br/wp-content/uploads/2024/08/metroviarios.jpg?zoom=2&amp;resize=310%2C165&amp;ssl=1 620w, https://i0.wp.com/marxismo.org.br/wp-content/uploads/2024/08/metroviarios.jpg?zoom=3&amp;resize=310%2C165&amp;ssl=1 930w" sizes="(max-width: 310px) 100vw, 310px" />									<span class="fa overlay-icon"></span>
								</a>
							</div><!-- post-thumbnail /-->
														<h3><a href="https://marxismo.org.br/os-motivos-pelos-quais-um-militante-da-oci-renuncia-ao-seu-posto-na-direcao-do-sindicato-dos-metroviarios-de-sp/" rel="bookmark">Os motivos pelos quais um militante da OCI renuncia ao seu posto na direção do Sindicato dos Metroviários de SP</a></h3>
							<p class="post-meta"><span class="tie-date"><i class="fa fa-clock-o"></i>01/08/2024</span></p>
						</div>
												<div class="related-item">
														<div class="post-thumbnail">
								<a href="https://marxismo.org.br/pedro-moro-pede-demissao-da-cptm-e-mais-uma-vez-a-farsa-da-privatizacao-e-exposta/" rel="bookmark">
									<img loading="lazy" width="310" height="165" src="https://i0.wp.com/marxismo.org.br/wp-content/uploads/2024/08/cptm-031-960x640-1.jpg?resize=310%2C165&amp;ssl=1" class="attachment-tie-medium size-tie-medium wp-post-image" alt="" decoding="async" srcset="https://i0.wp.com/marxismo.org.br/wp-content/uploads/2024/08/cptm-031-960x640-1.jpg?resize=310%2C165&amp;ssl=1 310w, https://i0.wp.com/marxismo.org.br/wp-content/uploads/2024/08/cptm-031-960x640-1.jpg?zoom=2&amp;resize=310%2C165&amp;ssl=1 620w, https://i0.wp.com/marxismo.org.br/wp-content/uploads/2024/08/cptm-031-960x640-1.jpg?zoom=3&amp;resize=310%2C165&amp;ssl=1 930w" sizes="(max-width: 310px) 100vw, 310px" />									<span class="fa overlay-icon"></span>
								</a>
							</div><!-- post-thumbnail /-->
														<h3><a href="https://marxismo.org.br/pedro-moro-pede-demissao-da-cptm-e-mais-uma-vez-a-farsa-da-privatizacao-e-exposta/" rel="bookmark">Pedro Moro pede demissão da CPTM e mais uma vez a farsa da privatização é exposta</a></h3>
							<p class="post-meta"><span class="tie-date"><i class="fa fa-clock-o"></i>01/08/2024</span></p>
						</div>
												<div class="related-item">
														<div class="post-thumbnail">
								<a href="https://marxismo.org.br/a-luta-pela-reducao-da-jornada-de-trabalho-sem-reducao-salarial/" rel="bookmark">
									<img loading="lazy" width="310" height="165" src="https://i0.wp.com/marxismo.org.br/wp-content/uploads/2024/07/SMABC-Comemoracao-de-primeiro-de-maio-trabalhadores-Sao-bernardo-dos-campos-sao-paulo-1980.jpg?resize=310%2C165&amp;ssl=1" class="attachment-tie-medium size-tie-medium wp-post-image" alt="" decoding="async" srcset="https://i0.wp.com/marxismo.org.br/wp-content/uploads/2024/07/SMABC-Comemoracao-de-primeiro-de-maio-trabalhadores-Sao-bernardo-dos-campos-sao-paulo-1980.jpg?resize=310%2C165&amp;ssl=1 310w, https://i0.wp.com/marxismo.org.br/wp-content/uploads/2024/07/SMABC-Comemoracao-de-primeiro-de-maio-trabalhadores-Sao-bernardo-dos-campos-sao-paulo-1980.jpg?zoom=2&amp;resize=310%2C165&amp;ssl=1 620w, https://i0.wp.com/marxismo.org.br/wp-content/uploads/2024/07/SMABC-Comemoracao-de-primeiro-de-maio-trabalhadores-Sao-bernardo-dos-campos-sao-paulo-1980.jpg?zoom=3&amp;resize=310%2C165&amp;ssl=1 930w" sizes="(max-width: 310px) 100vw, 310px" />									<span class="fa overlay-icon"></span>
								</a>
							</div><!-- post-thumbnail /-->
														<h3><a href="https://marxismo.org.br/a-luta-pela-reducao-da-jornada-de-trabalho-sem-reducao-salarial/" rel="bookmark">A luta pela redução da jornada de trabalho sem redução salarial </a></h3>
							<p class="post-meta"><span class="tie-date"><i class="fa fa-clock-o"></i>31/07/2024</span></p>
						</div>
												<div class="related-item">
														<div class="post-thumbnail">
								<a href="https://marxismo.org.br/abaixo-o-regime-assassino-de-hasina-vitoria-para-os-estudantes-de-bangladesh-declaracao-da-icr/" rel="bookmark">
									<img loading="lazy" width="310" height="165" src="https://i0.wp.com/marxismo.org.br/wp-content/uploads/2024/07/bangladesh.jpg?resize=310%2C165&amp;ssl=1" class="attachment-tie-medium size-tie-medium wp-post-image" alt="" decoding="async" srcset="https://i0.wp.com/marxismo.org.br/wp-content/uploads/2024/07/bangladesh.jpg?resize=310%2C165&amp;ssl=1 310w, https://i0.wp.com/marxismo.org.br/wp-content/uploads/2024/07/bangladesh.jpg?zoom=2&amp;resize=310%2C165&amp;ssl=1 620w, https://i0.wp.com/marxismo.org.br/wp-content/uploads/2024/07/bangladesh.jpg?zoom=3&amp;resize=310%2C165&amp;ssl=1 930w" sizes="(max-width: 310px) 100vw, 310px" />									<span class="fa overlay-icon"></span>
								</a>
							</div><!-- post-thumbnail /-->
														<h3><a href="https://marxismo.org.br/abaixo-o-regime-assassino-de-hasina-vitoria-para-os-estudantes-de-bangladesh-declaracao-da-icr/" rel="bookmark">Abaixo o regime assassino de Hasina! Vitória para os estudantes de Bangladesh! – Declaração da ICR</a></h3>
							<p class="post-meta"><span class="tie-date"><i class="fa fa-clock-o"></i>30/07/2024</span></p>
						</div>
												<div class="clear"></div>
					</div>
				</section>
				
			</div><!-- .post-inner -->
		</div><!-- .post-listing -->
	</div>
	<div class="clear"></div>
</div><!-- .container /-->

				
<div class="clear"></div>
<div class="footer-bottom">
	<div class="container">
		<div class="alignright">
					</div>
				<div class="social-icons">
		<a class="ttip-none" title="Facebook" href="https://www.facebook.com/oci.comunista" target="_blank"><i class="fa fa-facebook"></i></a><a class="ttip-none" title="Twitter" href="https://twitter.com/oci_comunista" target="_blank"><i class="fa fa-twitter"></i></a><a class="ttip-none" title="Youtube" href="https://www.youtube.com/user/esquerdamarxista" target="_blank"><i class="fa fa-youtube"></i></a><a class="ttip-none" title="instagram" href="https://www.instagram.com/oci.comunista/" target="_blank"><i class="fa fa-instagram"></i></a><a class="ttip-none" title="spotify" href="https://open.spotify.com/show/4fIEqAeSsFtSqOTC11xhwP?si=7c90538949c54da8" target="_blank"><i class="fa fa-spotify"></i></a>
		<a class="ttip-none"  title="TikTok" href="https://www.tiktok.com/@oci.comunista" target="_blank"><i class="fa &lt;i class=&quot;fa-brands fa-tiktok&quot; style=&quot;color: #e456b3;&quot;&gt;&lt;/i&gt;"></i></a>	</div>

		
		<div class="alignleft">
			© Copyright 2024, Esquerda Marxista		</div>
		<div class="clear"></div>
	</div><!-- .Container -->
</div><!-- .Footer bottom -->

</div><!-- .inner-Wrapper -->
</div><!-- #Wrapper -->
</div><!-- .Wrapper-outer -->
	<div id="topcontrol" class="fa fa-angle-up" title="Role Para Cima"></div>
<div id="fb-root"></div>

<div id="um_upload_single" style="display:none;"></div>

<div id="um_view_photo" style="display:none;">
	<a href="javascript:void(0);" data-action="um_remove_modal" class="um-modal-close" aria-label="Close view photo modal">
		<i class="um-faicon-times"></i>
	</a>

	<div class="um-modal-body photo">
		<div class="um-modal-photo"></div>
	</div>
</div>
			<script type='text/javascript'>
				const lazyloadRunObserver = () => {
					const lazyloadBackgrounds = document.querySelectorAll( `.e-con.e-parent:not(.e-lazyloaded)` );
					const lazyloadBackgroundObserver = new IntersectionObserver( ( entries ) => {
						entries.forEach( ( entry ) => {
							if ( entry.isIntersecting ) {
								let lazyloadBackground = entry.target;
								if( lazyloadBackground ) {
									lazyloadBackground.classList.add( 'e-lazyloaded' );
								}
								lazyloadBackgroundObserver.unobserve( entry.target );
							}
						});
					}, { rootMargin: '200px 0px 200px 0px' } );
					lazyloadBackgrounds.forEach( ( lazyloadBackground ) => {
						lazyloadBackgroundObserver.observe( lazyloadBackground );
					} );
				};
				const events = [
					'DOMContentLoaded',
					'elementor/lazyload/observe',
				];
				events.forEach( ( event ) => {
					document.addEventListener( event, lazyloadRunObserver );
				} );
			</script>
			<script type="text/javascript" id="tie-scripts-js-extra">
/* <![CDATA[ */
var tie = {"mobile_menu_active":"true","mobile_menu_top":"","lightbox_all":"true","lightbox_gallery":"true","woocommerce_lightbox":"","lightbox_skin":"dark","lightbox_thumb":"vertical","lightbox_arrows":"","sticky_sidebar":"1","is_singular":"","reading_indicator":"true","lang_no_results":"No Results","lang_results_found":"Results Found"};
/* ]]> */
</script>
<script type="text/javascript" src="https://marxismo.org.br/wp-content/themes/sahifa/js/tie-scripts.js" id="tie-scripts-js"></script>
<script type="text/javascript" src="https://marxismo.org.br/wp-content/themes/sahifa/js/ilightbox.packed.js" id="tie-ilightbox-js"></script>
<script type="text/javascript" src="https://c0.wp.com/c/6.6.1/wp-includes/js/underscore.min.js" id="underscore-js"></script>
<script type="text/javascript" id="wp-util-js-extra">
/* <![CDATA[ */
var _wpUtilSettings = {"ajax":{"url":"\/wp-admin\/admin-ajax.php"}};
/* ]]> */
</script>
<script type="text/javascript" src="https://c0.wp.com/c/6.6.1/wp-includes/js/wp-util.min.js" id="wp-util-js"></script>
<script type="text/javascript" src="https://c0.wp.com/c/6.6.1/wp-includes/js/dist/hooks.min.js" id="wp-hooks-js"></script>
<script type="text/javascript" src="https://c0.wp.com/c/6.6.1/wp-includes/js/dist/i18n.min.js" id="wp-i18n-js"></script>
<script type="text/javascript" id="wp-i18n-js-after">
/* <![CDATA[ */
wp.i18n.setLocaleData( { 'text direction\u0004ltr': [ 'ltr' ] } );
/* ]]> */
</script>
<script type="text/javascript" src="https://marxismo.org.br/wp-content/plugins/ultimate-member/assets/libs/tipsy/tipsy.min.js" id="um_tipsy-js"></script>
<script type="text/javascript" src="https://marxismo.org.br/wp-content/plugins/ultimate-member/assets/libs/um-confirm/um-confirm.min.js" id="um_confirm-js"></script>
<script type="text/javascript" src="https://marxismo.org.br/wp-content/plugins/ultimate-member/assets/libs/pickadate/picker.min.js" id="um_datetime-js"></script>
<script type="text/javascript" src="https://marxismo.org.br/wp-content/plugins/ultimate-member/assets/libs/pickadate/picker.date.min.js" id="um_datetime_date-js"></script>
<script type="text/javascript" src="https://marxismo.org.br/wp-content/plugins/ultimate-member/assets/libs/pickadate/picker.time.min.js" id="um_datetime_time-js"></script>
<script type="text/javascript" src="https://marxismo.org.br/wp-content/plugins/ultimate-member/assets/libs/pickadate/translations/pt_BR.min.js" id="um_datetime_locale-js"></script>
<script type="text/javascript" id="um_common-js-extra">
/* <![CDATA[ */
var um_common_variables = {"locale":"pt_BR"};
var um_common_variables = {"locale":"pt_BR"};
/* ]]> */
</script>
<script type="text/javascript" src="https://marxismo.org.br/wp-content/plugins/ultimate-member/assets/js/common.min.js" id="um_common-js"></script>
<script type="text/javascript" src="https://marxismo.org.br/wp-content/plugins/ultimate-member/assets/libs/cropper/cropper.min.js" id="um_crop-js"></script>
<script type="text/javascript" id="um_frontend_common-js-extra">
/* <![CDATA[ */
var um_frontend_common_variables = [];
/* ]]> */
</script>
<script type="text/javascript" src="https://marxismo.org.br/wp-content/plugins/ultimate-member/assets/js/common-frontend.min.js" id="um_frontend_common-js"></script>
<script type="text/javascript" src="https://marxismo.org.br/wp-content/plugins/ultimate-member/assets/js/um-modal.min.js" id="um_modal-js"></script>
<script type="text/javascript" src="https://marxismo.org.br/wp-content/plugins/ultimate-member/assets/libs/jquery-form/jquery-form.min.js" id="um_jquery_form-js"></script>
<script type="text/javascript" src="https://marxismo.org.br/wp-content/plugins/ultimate-member/assets/libs/fileupload/fileupload.js" id="um_fileupload-js"></script>
<script type="text/javascript" src="https://marxismo.org.br/wp-content/plugins/ultimate-member/assets/js/um-functions.min.js" id="um_functions-js"></script>
<script type="text/javascript" src="https://marxismo.org.br/wp-content/plugins/ultimate-member/assets/js/um-responsive.min.js" id="um_responsive-js"></script>
<script type="text/javascript" src="https://marxismo.org.br/wp-content/plugins/ultimate-member/assets/js/um-conditional.min.js" id="um_conditional-js"></script>
<script type="text/javascript" src="https://marxismo.org.br/wp-content/plugins/ultimate-member/assets/libs/select2/select2.full.min.js" id="select2-js"></script>
<script type="text/javascript" src="https://marxismo.org.br/wp-content/plugins/ultimate-member/assets/libs/select2/i18n/pt.js" id="um_select2_locale-js"></script>
<script type="text/javascript" src="https://marxismo.org.br/wp-content/plugins/ultimate-member/assets/libs/raty/um-raty.min.js" id="um_raty-js"></script>
<script type="text/javascript" id="um_scripts-js-extra">
/* <![CDATA[ */
var um_scripts = {"max_upload_size":"2147483648","nonce":"d013f783e1"};
/* ]]> */
</script>
<script type="text/javascript" src="https://marxismo.org.br/wp-content/plugins/ultimate-member/assets/js/um-scripts.min.js" id="um_scripts-js"></script>
<script type="text/javascript" src="https://marxismo.org.br/wp-content/plugins/ultimate-member/assets/js/um-profile.min.js" id="um_profile-js"></script>
<script type="text/javascript" src="https://marxismo.org.br/wp-content/plugins/ultimate-member/assets/js/um-account.min.js" id="um_account-js"></script>
<script type="text/javascript" src="https://stats.wp.com/e-202431.js" id="jetpack-stats-js" data-wp-strategy="defer"></script>
<script type="text/javascript" id="jetpack-stats-js-after">
/* <![CDATA[ */
_stq = window._stq || [];
_stq.push([ "view", JSON.parse("{\"v\":\"ext\",\"blog\":\"122437044\",\"post\":\"0\",\"tz\":\"-3\",\"srv\":\"marxismo.org.br\",\"j\":\"1:13.6\"}") ]);
_stq.push([ "clickTrackerInit", "122437044", "0" ]);
/* ]]> */
</script>
		<script type="text/javascript">
			jQuery( window ).on( 'load', function() {
				jQuery('input[name="um_request"]').val('');
			});
		</script>
	</body>
</html>